import React from "react";
import { View, Text, TouchableOpacity, Image, StyleSheet } from "react-native";
import Ionicons from 'react-native-vector-icons/Ionicons';

export default function SuccessScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Image
        source={{ uri: "https://cdn-icons-png.flaticon.com/512/190/190411.png" }}
        style={styles.successImage}
      />
      
      <Text style={styles.title}>Payment Success, Yayy! 🎉</Text>

      <TouchableOpacity style={styles.continueButton} onPress={() => navigation.navigate("Main")}>
        <Text style={styles.continueButtonText}>Tiếp tục mua sắm</Text>
      </TouchableOpacity>
    </View>
  );
}

// Vô hiệu hóa cử chỉ vuốt để quay lại trang trước
SuccessScreen.navigationOptions = {
  gestureEnabled: false,
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F5F5F5",
    padding: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  successImage: {
    width: 100,
    height: 100,
    marginBottom: 20,
  },
  title: {
    fontSize: 22,
    fontWeight: "bold",
  },
  subtitle: {
    textAlign: "center",
    color: "gray",
    marginTop: 5,
  },
  continueButton: {
    backgroundColor: "#b2275b",
    padding: 15,
    borderRadius: 10,
    alignItems: "center",
    marginTop: 10,
    width: "80%",
  },
  continueButtonText: {
    color: "white",
    fontWeight: "bold",
  },
});