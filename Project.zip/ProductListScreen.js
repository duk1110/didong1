import React, { useState } from 'react';
import { View, Text, FlatList, Image, TouchableOpacity, StyleSheet, Alert, Modal } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import productsData from '../assets/data/products.json';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons } from '@expo/vector-icons'; // Thêm để sử dụng biểu tượng
import { imageMap } from './imageMap';

const ProductListScreen = ({ route }) => {
  const { categoryId } = route.params;
  const navigation = useNavigation();
  const products = productsData.filter(product => product.categoryId === categoryId);
  const [showSuccessModal, setShowSuccessModal] = useState(false); // Khai báo state cho Modal

  const handleProductPress = (productId) => {
    navigation.navigate('ProductDetail', { productId });
  };

  const handleAddToCart = async (product) => {
    try {
      const cart = await AsyncStorage.getItem('cart');
      const cartArray = cart ? JSON.parse(cart) : [];

      const existingItem = cartArray.find(item => item.id === product.id);
      if (existingItem) {
        existingItem.quantity = (existingItem.quantity || 0) + 1;
      } else {
        cartArray.push({ ...product, quantity: 1 });
      }

      await AsyncStorage.setItem('cart', JSON.stringify(cartArray));
      setShowSuccessModal(true); // Hiển thị Modal khi thêm thành công
      setTimeout(() => setShowSuccessModal(false), 1500); // Ẩn Modal sau 1.5 giây
    } catch (error) {
      console.error('Error adding to cart:', error);
      Alert.alert('Error', 'Failed to add item to cart.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>{productsData.find(cat => cat.id === categoryId)?.name || 'Products'}</Text>
      <FlatList
        data={products}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.productItem}>
            <TouchableOpacity onPress={() => handleProductPress(item.id)} style={styles.productTouch}>
              <Image
                source={imageMap[item.image] || { uri: item.image }}
                style={styles.productImage}
              />
              <View style={styles.productDetails}>
                <Text style={styles.productName}>{item.name}</Text>
                <Text style={styles.productSize}>
                  {item.size || (item.name.includes('Can') ? '355ml' : '2L')} Price
                </Text>
                <Text style={styles.productPrice}>${item.price.toFixed(2)}</Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity style={styles.addButton} onPress={() => handleAddToCart(item)}>
              <Text style={styles.addButtonText}>+</Text>
            </TouchableOpacity>
          </View>
        )}
        ListEmptyComponent={<Text style={styles.emptyText}>No products in this category</Text>}
      />
      <Modal visible={showSuccessModal} transparent animationType="fade">
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Ionicons name="checkmark-circle" size={40} color="#b2275b" />
            <Text style={styles.modalText}>Thêm thành công!</Text>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  header: {
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 12,
  },
  productItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    backgroundColor: '#f9f9f9',
    borderRadius: 10,
    marginBottom: 10,
  },
  productTouch: {
    flexDirection: 'row',
    flex: 1,
    alignItems: 'center',
  },
  productImage: {
    width: 60,
    height: 60,
    borderRadius: 10,
  },
  productDetails: {
    flex: 1,
    marginLeft: 10,
  },
  productName: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  productSize: {
    fontSize: 12,
    color: '#666',
  },
  productPrice: {
    fontSize: 14,
    color: '#b2275b',
    fontWeight: 'bold',
  },
  addButton: {
    backgroundColor: '#b2275b',
    width: 30,
    height: 30,
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 10,
  },
  addButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  emptyText: {
    textAlign: 'center',
    fontSize: 16,
    color: '#666',
    marginTop: 20,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  modalContent: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
  },
  modalText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#b2275b',
    marginTop: 10,
  },
});

export default ProductListScreen;