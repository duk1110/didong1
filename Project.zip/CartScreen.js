import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, FlatList, Image, StyleSheet, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { imageMap } from './imageMap';

const CartScreen = () => {
  const navigation = useNavigation();
  const [cartItems, setCartItems] = useState([]);
  const [totalAmount, setTotalAmount] = useState(0);

  useEffect(() => {
    const loadCart = async () => {
      try {
        const cart = await AsyncStorage.getItem('cart');
        const cartArray = cart ? JSON.parse(cart) : [];
        setCartItems(cartArray);
        calculateTotal(cartArray);
      } catch (error) {
        console.error('Error loading cart:', error);
      }
    };

    // Lắng nghe thay đổi từ AsyncStorage (nếu có thư viện hỗ trợ, hoặc sử dụng interval đơn giản)
    const interval = setInterval(loadCart, 1000); // Cập nhật mỗi giây
    return () => clearInterval(interval);
  }, []);

  const calculateTotal = (items) => {
    const total = items.reduce((sum, item) => sum + item.price * (item.quantity || 1), 0);
    setTotalAmount(total);
  };

  const handleQuantityChange = async (item, change) => {
    const updatedCart = cartItems.map(cartItem => {
      if (cartItem.id === item.id) {
        const newQuantity = Math.max(0, (cartItem.quantity || 1) + change);
        return { ...cartItem, quantity: newQuantity };
      }
      return cartItem;
    });

    // Lọc ra các sản phẩm có quantity > 0
    const filteredCart = updatedCart.filter(item => item.quantity > 0);
    setCartItems(filteredCart);
    calculateTotal(filteredCart);
    await AsyncStorage.setItem('cart', JSON.stringify(filteredCart));
  };

  const handleRemoveItem = async (itemId) => {
    Alert.alert(
      "Remove Item",
      "Are you sure you want to remove this item?",
      [
        { text: "Cancel", style: "cancel" },
        { text: "OK", onPress: async () => {
          const updatedCart = cartItems.filter(item => item.id !== itemId);
          setCartItems(updatedCart);
          calculateTotal(updatedCart);
          await AsyncStorage.setItem('cart', JSON.stringify(updatedCart));
        }}
      ]
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>My Cart</Text>
      
      <FlatList
        data={cartItems}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.cartItem}>
            <Image source={imageMap[item.image] || item.image} style={styles.itemImage} />
            <View style={styles.itemDetails}>
              <Text style={styles.itemName}>{item.name}</Text>
              <Text style={styles.itemPrice}>${item.price.toFixed(2)}</Text>
            </View>
            <View style={styles.quantityContainer}>
              <TouchableOpacity style={styles.quantityButton} onPress={() => handleQuantityChange(item, -1)}>
                <Text style={styles.quantityText}>-</Text>
              </TouchableOpacity>
              <Text style={styles.quantityNumber}>{item.quantity || 1}</Text>
              <TouchableOpacity style={styles.quantityButton} onPress={() => handleQuantityChange(item, 1)}>
                <Text style={styles.quantityText}>+</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => handleRemoveItem(item.id)}>
                <Ionicons name="close" size={20} color="#fff" />
              </TouchableOpacity>
            </View>
          </View>
        )}
        ListEmptyComponent={<Text style={styles.emptyText}>Your cart is empty</Text>}
      />

      <Text style={styles.totalText}>Total</Text>
      <Text style={styles.totalAmount}>${totalAmount.toFixed(2)}</Text>

      <TouchableOpacity
        style={[styles.checkoutButton, totalAmount === 0 && styles.disabledButton]}
        onPress={() => totalAmount > 0 && navigation.navigate('Payment')}
        disabled={totalAmount === 0}
      >
        <Text style={styles.checkoutText}>Checkout</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 20,
    marginBottom: 10,
    textAlign: 'center',
  },
  cartItem: {
    flexDirection: 'row',
    backgroundColor: '#F9F9F9',
    borderRadius: 10,
    padding: 15,
    marginVertical: 8,
    alignItems: 'center',
  },
  itemImage: {
    width: 60,
    height: 60,
    borderRadius: 10,
  },
  itemDetails: {
    flex: 1,
    marginLeft: 15,
  },
  itemName: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  itemPrice: {
    fontSize: 14,
    color: '#b2275b',
    fontWeight: 'bold',
  },
  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  quantityButton: {
    backgroundColor: '#b2275b',
    width: 30,
    height: 30,
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 5,
  },
  quantityText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  quantityNumber: {
    fontSize: 16,
    marginHorizontal: 10,
  },
  totalText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 20,
  },
  totalAmount: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#b2275b',
  },
  checkoutButton: {
    backgroundColor: '#b2275b',
    padding: 15,
    borderRadius: 10,
    marginTop: 20,
    alignItems: 'center',
  },
  disabledButton: {
    backgroundColor: '#ccc',
  },
  checkoutText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  emptyText: {
    textAlign: 'center',
    fontSize: 16,
    color: '#666',
    marginTop: 20,
  },
});

export default CartScreen;