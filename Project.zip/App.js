import React, { useContext } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { AppProvider } from './AppContext';
import AppContext from './AppContext';
import SplashScreen from './SplashScreen';
import LogInScreen from './LogInScreen';
import SignUpScreen from './SignUpScreen';
import HomeScreen from './HomeScreen';
import ProfileScreen from './ProfileScreen';
import ExploreScreen from './ExploreScreen';
import CartScreen from './CartScreen';
import FavouriteScreen from './FavouriteScreen';
import ProductDetailScreen from './ProductDetailScreen';
import ProductListScreen from './ProductListScreen';
import PaymentScreen from './PaymentScreen';
import SuccessScreen from './SuccessScreen';
import ForgetPasswordScreen from './ForgetPasswordScreen';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

const MainTabScreen = () => (
  <Tab.Navigator
    screenOptions={{
      headerShown: false,
      tabBarActiveTintColor: '#b2275b',
      tabBarInactiveTintColor: 'gray',
    }}
  >
    <Tab.Screen 
      name="Shop" 
      component={HomeScreen} 
      options={{ 
        tabBarIcon: ({ color, size }) => <Ionicons name="storefront-outline" size={size} color={color} />
      }} 
    />
    <Tab.Screen 
      name="Explore" 
      component={ExploreScreen} 
      options={{ 
        tabBarIcon: ({ color, size }) => <Ionicons name="search-outline" size={size} color={color} /> 
      }} 
    />
    <Tab.Screen 
      name="Cart" 
      component={CartScreen} 
      options={{ 
        tabBarIcon: ({ color, size }) => <Ionicons name="cart-outline" size={size} color={color} /> 
      }} 
    />
    <Tab.Screen 
      name="Favourite" 
      component={FavouriteScreen} 
      options={{ 
        tabBarIcon: ({ color, size }) => <Ionicons name="heart-outline" size={size} color={color} /> 
      }} 
    />
    <Tab.Screen 
      name="Account" 
      component={ProfileScreen} 
      options={{ 
        tabBarIcon: ({ color, size }) => <Ionicons name="person-outline" size={size} color={color} /> 
      }} 
    />
  </Tab.Navigator>
);

const AppContent = () => {
  const { isLoggedIn } = useContext(AppContext);

  return (
    <NavigationContainer>
      {isLoggedIn ? (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
          <Stack.Screen name="Main" component={MainTabScreen} />
          <Stack.Screen name="ProductDetail" component={ProductDetailScreen} />
          <Stack.Screen name="ProductList" component={ProductListScreen} />
          <Stack.Screen name="Payment" component={PaymentScreen} />
          <Stack.Screen name="Success" component={SuccessScreen} />
        </Stack.Navigator>
      ) : (
        <Stack.Navigator initialRouteName="Splash" screenOptions={{ headerShown: false }}>
          <Stack.Screen name="Splash" component={SplashScreen} />
          <Stack.Screen name="LogIn" component={LogInScreen} />
          <Stack.Screen name="SignUp" component={SignUpScreen} />
          <Stack.Screen name="ForgetPassword" component={ForgetPasswordScreen} />
        </Stack.Navigator>
      )}
    </NavigationContainer>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}