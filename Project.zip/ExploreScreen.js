import React, { useState } from 'react';
import { View, Text, TextInput, FlatList, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import categoriesData from '../assets/data/categories.json';
import productsData from '../assets/data/products.json';
import { imageMap } from './imageMap';

export default function ExploreScreen() {
  const navigation = useNavigation();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState(null);

  // Filter categories based on search query
  const filteredCategories = searchQuery
    ? categoriesData.filter(category =>
        category.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        productsData.some(product =>
          product.categoryId === category.id &&
          product.name.toLowerCase().includes(searchQuery.toLowerCase())
        )
      )
    : categoriesData;

  const handleCategoryPress = (categoryId) => {
    navigation.navigate('ProductList', { categoryId, searchQuery });
    setSelectedCategory(categoryId);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Find Products</Text>

      <View style={styles.searchBar}>
        <Ionicons name="search-outline" size={20} color="gray" />
        <TextInput
          placeholder="Search Store"
          style={styles.searchInput}
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>

      <FlatList
        data={filteredCategories}
        keyExtractor={(item) => item.id.toString()}
        numColumns={2}
        columnWrapperStyle={styles.categoryRow}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.categoryItem}
            onPress={() => handleCategoryPress(item.id)}
          >
            <Image
              source={imageMap[item.image] || { uri: item.image }}
              style={styles.categoryImage}
              resizeMode="contain"
            />
            <Text style={styles.categoryTitle}>{item.name}</Text>
          </TouchableOpacity>
        )}
        ListEmptyComponent={<Text style={styles.emptyText}>Không tìm thấy danh mục</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 20,
    marginBottom: 12,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f2f2f2',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    marginBottom: 16,
  },
  searchInput: {
    marginLeft: 10,
    fontSize: 16,
    flex: 1,
  },
  categoryRow: {
    justifyContent: 'space-between',
  },
  categoryItem: {
    backgroundColor: '#f9f9f9',
    borderRadius: 12,
    padding: 10,
    alignItems: 'center',
    marginBottom: 16,
    width: '48%',
  },
  categoryImage: {
    width: 80,
    height: 80,
    marginBottom: 8,
  },
  categoryTitle: {
    textAlign: 'center',
    fontSize: 14,
  },
  emptyText: {
    textAlign: 'center',
    fontSize: 16,
    color: '#666',
    marginTop: 20,
  },
});