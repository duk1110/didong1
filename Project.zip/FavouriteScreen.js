import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, Image, TouchableOpacity, StyleSheet, Modal } from 'react-native';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { imageMap } from './imageMap';

const FavouriteScreen = () => {
  const navigation = useNavigation();
  const [favourites, setFavourites] = useState([]);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [isAddButtonDisabled, setIsAddButtonDisabled] = useState(false);

  const loadFavourites = async () => {
    try {
      const favouritesData = await AsyncStorage.getItem('favourites');
      const favouritesArray = favouritesData ? JSON.parse(favouritesData) : [];
      setFavourites(favouritesArray);
      // Kích hoạt lại nút nếu danh sách yêu thích không rỗng
      setIsAddButtonDisabled(favouritesArray.length === 0);
    } catch (error) {
      console.error('Error loading favourites:', error);
    }
  };

  useEffect(() => {
    loadFavourites();
  }, []);

  useFocusEffect(
    React.useCallback(() => {
      loadFavourites();
    }, [])
  );

  const handleRemoveFavourite = async (productId) => {
    try {
      const updatedFavourites = favourites.filter(item => item.id !== productId);
      await AsyncStorage.setItem('favourites', JSON.stringify(updatedFavourites));
      setFavourites(updatedFavourites);
      // Vô hiệu hóa nút nếu danh sách yêu thích rỗng
      setIsAddButtonDisabled(updatedFavourites.length === 0);
    } catch (error) {
      console.error('Error removing favourite:', error);
    }
  };

  const handleAddAllToCart = async () => {
    try {
      const cart = await AsyncStorage.getItem('cart');
      const cartArray = cart ? JSON.parse(cart) : [];
      
      favourites.forEach(favItem => {
        const existingItem = cartArray.find(item => item.id === favItem.id);
        if (existingItem) {
          existingItem.quantity = (existingItem.quantity || 0) + 1;
        } else {
          cartArray.push({ ...favItem, quantity: 1 });
        }
      });

      await AsyncStorage.setItem('cart', JSON.stringify(cartArray));
      
      // Xóa danh sách yêu thích
      await AsyncStorage.setItem('favourites', JSON.stringify([]));
      setFavourites([]);
      
      // Hiển thị thông báo thành công
      setShowSuccessModal(true);
      setTimeout(() => setShowSuccessModal(false), 1500); // Ẩn modal sau 1.5 giây
      
      // Vô hiệu hóa nút "Add All to Cart"
      setIsAddButtonDisabled(true);
    } catch (error) {
      console.error('Error adding to cart:', error);
      Alert.alert('Error', 'Failed to add items to cart.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Favourites</Text>
      
      <FlatList
        data={favourites}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.favouriteItem}>
            <Image source={imageMap[item.image] || { uri: item.image }} style={styles.itemImage} />
            <View style={styles.itemDetails}>
              <Text style={styles.itemName}>{item.name}</Text>
              <Text style={styles.itemPrice}>${item.price.toFixed(2)}</Text>
            </View>
            <TouchableOpacity onPress={() => handleRemoveFavourite(item.id)}>
              <Ionicons name="heart" size={24} color="#b2275b" />
            </TouchableOpacity>
          </View>
        )}
        ListEmptyComponent={<Text style={styles.emptyText}>No favourites yet</Text>}
        ListFooterComponent={
          <TouchableOpacity
            style={[styles.addToCartButton, isAddButtonDisabled && styles.disabledButton]}
            onPress={handleAddAllToCart}
            disabled={isAddButtonDisabled}
          >
            <Text style={styles.addToCartText}>Add All to Cart</Text>
          </TouchableOpacity>
        }
      />

      <Modal visible={showSuccessModal} transparent animationType="fade">
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Ionicons name="checkmark-circle" size={40} color="#b2275b" />
            <Text style={styles.modalText}>Thêm thành công!</Text>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginTop:20,
    marginBottom: 10,
    textAlign: 'center',
  },
  favouriteItem: {
    flexDirection: 'row',
    backgroundColor: '#F9F9F9',
    borderRadius: 10,
    padding: 15,
    marginVertical: 8,
    alignItems: 'center',
  },
  itemImage: {
    width: 60,
    height: 60,
    borderRadius: 10,
  },
  itemDetails: {
    flex: 1,
    marginLeft: 15,
  },
  itemName: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  itemPrice: {
    fontSize: 14,
    color: '#b2275b',
    fontWeight: 'bold',
  },
  emptyText: {
    textAlign: 'center',
    fontSize: 16,
    color: '#666',
    marginTop: 20,
  },
  addToCartButton: {
    backgroundColor: '#b2275b',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 20,
  },
  disabledButton: {
    backgroundColor: '#d3d3d3',
  },
  addToCartText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  modalContent: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
  },
  modalText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#b2275b',
    marginTop: 10,
  },
});

export default FavouriteScreen;