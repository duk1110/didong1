import React, { useContext, useState, useEffect } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, FlatList, Modal, TextInput } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppContext from './AppContext';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system';

const ProfileScreen = () => {
  const { setIsLoggedIn } = useContext(AppContext);
  const navigation = useNavigation();
  const [userData, setUserData] = useState({ username: 'Guest', email: 'No email' });
  const [orders, setOrders] = useState([]);
  const [showOrdersModal, setShowOrdersModal] = useState(false);
  const [showAddressModal, setShowAddressModal] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [address, setAddress] = useState({ street: '', district: '', city: '' });
  const [details, setDetails] = useState({ username: '', phone: '', password: '' });

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const currentUserEmail = await AsyncStorage.getItem('currentUserEmail');
        if (!currentUserEmail) {
          setUserData({ username: 'Guest', email: 'No email' });
          return;
        }

        const filePath = `${FileSystem.documentDirectory}users.json`;
        const fileInfo = await FileSystem.getInfoAsync(filePath);
        if (!fileInfo.exists) {
          setUserData({ username: 'Guest', email: 'No email' });
          return;
        }

        const fileContent = await FileSystem.readAsStringAsync(filePath);
        const users = JSON.parse(fileContent);
        const user = users.find(u => u.email === currentUserEmail);
        
        if (user) {
          setUserData({ username: user.username || 'Guest', email: user.email || 'No email' });
          setAddress({
            street: user.address?.street || '',
            district: user.address?.district || '',
            city: user.address?.city || ''
          });
          setDetails({
            username: user.username || '',
            phone: user.phone || '',
            password: user.password || ''
          });
        } else {
          setUserData({ username: 'Guest', email: 'No email' });
        }
      } catch (error) {
        console.log('Error fetching user data:', error);
        setUserData({ username: 'Guest', email: 'No email' });
      }
    };

    const fetchOrders = async () => {
      try {
        const currentUserEmail = await AsyncStorage.getItem('currentUserEmail');
        if (!currentUserEmail) return;

        const filePath = `${FileSystem.documentDirectory}orders.json`;
        const fileInfo = await FileSystem.getInfoAsync(filePath);
        if (!fileInfo.exists) {
          await FileSystem.writeAsStringAsync(filePath, '[]');
          setOrders([]);
          return;
        }

        const fileContent = await FileSystem.readAsStringAsync(filePath);
        const ordersData = JSON.parse(fileContent);
        const userOrders = ordersData.filter(order => order.userEmail === currentUserEmail);
        setOrders(userOrders);
      } catch (error) {
        console.error('Error fetching orders:', error);
        setOrders([]);
      }
    };

    fetchUserData();
    fetchOrders();
  }, []);

  const handleUpdateAddress = async () => {
    try {
      const currentUserEmail = await AsyncStorage.getItem('currentUserEmail');
      if (!currentUserEmail) return;

      const filePath = `${FileSystem.documentDirectory}users.json`;
      const fileContent = await FileSystem.readAsStringAsync(filePath);
      const users = JSON.parse(fileContent);

      const updatedUsers = users.map(user => {
        if (user.email === currentUserEmail) {
          return { ...user, address };
        }
        return user;
      });

      await FileSystem.writeAsStringAsync(filePath, JSON.stringify(updatedUsers));
      setShowAddressModal(false);
    } catch (error) {
      console.error('Error updating address:', error);
    }
  };

  const handleUpdateDetails = async () => {
    try {
      const currentUserEmail = await AsyncStorage.getItem('currentUserEmail');
      if (!currentUserEmail) return;

      const filePath = `${FileSystem.documentDirectory}users.json`;
      const fileContent = await FileSystem.readAsStringAsync(filePath);
      const users = JSON.parse(fileContent);

      const updatedUsers = users.map(user => {
        if (user.email === currentUserEmail) {
          return { ...user, username: details.username, phone: details.phone, password: details.password };
        }
        return user;
      });

      await FileSystem.writeAsStringAsync(filePath, JSON.stringify(updatedUsers));
      setUserData({ ...userData, username: details.username });
      setShowDetailsModal(false);
    } catch (error) {
      console.error('Error updating details:', error);
    }
  };

  const handleLogout = async () => {
    try {
      await AsyncStorage.removeItem('currentUserEmail');
      setIsLoggedIn(false);
    } catch (error) {
      console.log('Error during logout:', error);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.profileSection}>
        <Image
          source={{ uri: 'https://th.bing.com/th/id/OIP.SqAptXmL4gGkA1nKw_CLJwHaHa?rs=1&pid=ImgDetMain' }}
          style={styles.avatar}
        />
        <Text style={styles.name}>{userData.username}</Text>
        <Text style={styles.email}>{userData.email}</Text>
      </View>

      <View style={styles.menuList}>
        <MenuItem icon="cart-outline" title="Orders" onPress={() => setShowOrdersModal(true)} />
        <MenuItem icon="person-outline" title="My Details" onPress={() => setShowDetailsModal(true)} />
        <MenuItem icon="location-outline" title="Delivery Address" onPress={() => setShowAddressModal(true)} />
      </View>

      <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
        <Ionicons name="log-out-outline" size={20} color="#b2275b" />
        <Text style={styles.logoutText}>Log Out</Text>
      </TouchableOpacity>

      <Modal visible={showOrdersModal} transparent animationType="slide">
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Your Orders</Text>
            <TouchableOpacity onPress={() => setShowOrdersModal(false)}>
              <Ionicons name="close" size={24} color="#000" />
            </TouchableOpacity>
            <FlatList
              data={orders}
              keyExtractor={(item) => item.id}
              renderItem={({ item }) => (
                <View style={styles.orderItem}>
                  <Text style={styles.orderDate}>{new Date(item.date).toLocaleDateString()}</Text>
                  <Text style={styles.orderTotal}>Total: $ {item.total.toFixed(2)}</Text>
                  {item.items.map(product => (
                    <Text key={product.id} style={styles.orderProduct}>
                      {product.name} (x{product.quantity})
                    </Text>
                  ))}
                  {item.promo && (
                    <Text style={styles.orderPromo}>Promo: {item.promo}</Text>
                  )}
                </View>
              )}
              ListEmptyComponent={<Text style={styles.emptyText}>No orders yet</Text>}
            />
          </View>
        </View>
      </Modal>

      <Modal visible={showAddressModal} transparent animationType="slide">
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Update Delivery Address</Text>
            <TextInput
              style={styles.input}
              placeholder="Street"
              value={address.street}
              onChangeText={(text) => setAddress({ ...address, street: text })}
            />
            <TextInput
              style={styles.input}
              placeholder="District"
              value={address.district}
              onChangeText={(text) => setAddress({ ...address, district: text })}
            />
            <TextInput
              style={styles.input}
              placeholder="City"
              value={address.city}
              onChangeText={(text) => setAddress({ ...address, city: text })}
            />
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setShowAddressModal(false)}
              >
                <Text style={styles.buttonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.saveButton]}
                onPress={handleUpdateAddress}
              >
                <Text style={styles.buttonText}>Save</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <Modal visible={showDetailsModal} transparent animationType="slide">
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Update My Details</Text>
            <TextInput
              style={styles.input}
              placeholder="Username"
              value={details.username}
              onChangeText={(text) => setDetails({ ...details, username: text })}
            />
            <TextInput
              style={styles.input}
              placeholder="Phone Number"
              value={details.phone}
              onChangeText={(text) => setDetails({ ...details, phone: text })}
              keyboardType="phone-pad"
            />
            <TextInput
              style={styles.input}
              placeholder="Password"
              value={details.password}
              onChangeText={(text) => setDetails({ ...details, password: text })}
              secureTextEntry
            />
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setShowDetailsModal(false)}
              >
                <Text style={styles.buttonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.saveButton]}
                onPress={handleUpdateDetails}
              >
                <Text style={styles.buttonText}>Save</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const MenuItem = ({ icon, title, onPress }) => (
  <TouchableOpacity style={styles.menuItem} activeOpacity={0.7} onPress={onPress}>
    <Ionicons name={icon} size={22} color="#b2275b" />
    <Text style={styles.menuText}>{title}</Text>
    <Ionicons name="chevron-forward-outline" size={20} color="gray" />
  </TouchableOpacity>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f8f8',
  },
  profileSection: {
    alignItems: 'center',
    paddingVertical: 20,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  avatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginTop: 20,
    marginBottom: 10,
  },
  name: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  email: {
    fontSize: 14,
    color: 'gray',
    marginTop: 5,
  },
  menuList: {
    marginTop: 10,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
    backgroundColor: '#fff',
    marginBottom: 1,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  menuText: {
    flex: 1,
    fontSize: 16,
    marginLeft: 15,
    color: '#333',
  },
  logoutButton: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 10,
    margin: 20,
    borderWidth: 1,
    borderColor: '#b2275b',
  },
  logoutText: {
    color: '#b2275b',
    fontWeight: 'bold',
    marginLeft: 5,
    fontSize: 16,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalContent: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 20,
    margin: 20,
    maxHeight: '80%',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
  },
  orderItem: {
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    paddingVertical: 10,
  },
  orderDate: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  orderTotal: {
    fontSize: 14,
    color: '#b2275b',
  },
  orderProduct: {
    fontSize: 14,
    color: '#666',
  },
  orderPromo: {
    fontSize: 14,
    color: '#666',
  },
  emptyText: {
    textAlign: 'center',
    fontSize: 16,
    color: '#666',
  },
  input: {
    borderWidth: 1,
    borderColor: '#eee',
    borderRadius: 10,
    padding: 10,
    marginBottom: 10,
    fontSize: 16,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  modalButton: {
    flex: 1,
    padding: 12,
    borderRadius: 10,
    alignItems: 'center',
    marginHorizontal: 5,
  },
  cancelButton: {
    backgroundColor: '#eee',
  },
  saveButton: {
    backgroundColor: '#b2275b',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default ProfileScreen;