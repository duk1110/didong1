import React, { useState, useEffect } from "react";
import { View, Text, TouchableOpacity, Modal, StyleSheet, FlatList, Alert } from "react-native";
import Ionicons from 'react-native-vector-icons/Ionicons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system';

export default function PaymentScreen({ navigation }) {
  const [totalAmount, setTotalAmount] = useState(0);
  const [cartItems, setCartItems] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [promoCode, setPromoCode] = useState(null);
  const SHIPPING_COST = 10; // Giá vận chuyển cố định $10

  useEffect(() => {
    const loadCart = async () => {
      try {
        const cart = await AsyncStorage.getItem('cart');
        const cartArray = cart ? JSON.parse(cart) : [];
        setCartItems(cartArray);
        const subtotal = cartArray.reduce((sum, item) => sum + item.price * (item.quantity || 1), 0);
        const total = subtotal + SHIPPING_COST; // Thêm phí vận chuyển
        setTotalAmount(total);
      } catch (error) {
        console.error('Error loading cart:', error);
      }
    };
    loadCart();
  }, []);

  const handlePlaceOrder = async () => {
    try {
      const currentUserEmail = await AsyncStorage.getItem('currentUserEmail');
      if (!currentUserEmail) {
        alert('Please log in to place an order.');
        return;
      }

      const cart = await AsyncStorage.getItem('cart');
      const cartArray = cart ? JSON.parse(cart) : [];
      const order = {
        id: Date.now().toString(),
        userEmail: currentUserEmail,
        items: cartArray,
        total: totalAmount,
        promo: promoCode,
        date: new Date().toISOString(),
      };

      const filePath = `${FileSystem.documentDirectory}orders.json`;
      const fileInfo = await FileSystem.getInfoAsync(filePath);
      let orders = [];
      if (fileInfo.exists) {
        const fileContent = await FileSystem.readAsStringAsync(filePath);
        orders = JSON.parse(fileContent);
      }
      orders.push(order);
      await FileSystem.writeAsStringAsync(filePath, JSON.stringify(orders));

      await AsyncStorage.removeItem('cart');
      setShowModal(false); // Ẩn modal sau khi đặt hàng
      navigation.navigate('Success');
    } catch (error) {
      console.error('Error placing order:', error);
      alert('Error placing order.');
    }
  };

  const renderCartItem = ({ item }) => (
    <View style={styles.cartItem}>
      <Text style={styles.itemName}>{item.name}</Text>
      <Text style={styles.itemPrice}>${(item.price * (item.quantity || 1)).toFixed(2)}</Text>
      <Text style={styles.itemQuantity}>x{item.quantity || 1}</Text>
    </View>
  );

  const applyPromoCode = (code) => {
    const subtotal = cartItems.reduce((sum, item) => sum + item.price * (item.quantity || 1), 0);
    let newTotal = subtotal + SHIPPING_COST;

    if (code === '20%') {
      newTotal = newTotal * 0.8; // Giảm 20%
    } else if (code === 'freeship') {
      newTotal = subtotal; // Miễn phí vận chuyển
    }

    setPromoCode(code);
    setTotalAmount(newTotal);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>My Cart</Text>

      <FlatList
        data={cartItems}
        renderItem={renderCartItem}
        keyExtractor={(item) => item.id}
        ListEmptyComponent={<Text style={styles.emptyText}>Your cart is empty</Text>}
        ListFooterComponent={
          <TouchableOpacity style={styles.checkoutButton} onPress={() => setShowModal(true)}>
            <Text style={styles.checkoutText}>Checkout</Text>
            <Ionicons name="chevron-forward" size={20} color="#fff" />
          </TouchableOpacity>
        }
      />

      <Modal visible={showModal} transparent animationType="slide">
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Checkout</Text>
            <TouchableOpacity onPress={() => setShowModal(false)} style={styles.closeModal}>
              <Ionicons name="close" size={24} color="#000" />
            </TouchableOpacity>

            <View style={styles.optionRow}>
              <Text style={styles.optionLabel}>Delivery</Text>
              <Text style={styles.optionValue}>Cash on Delivery ($10)</Text>
            </View>

            <View style={styles.optionRow}>
              <Text style={styles.optionLabel}>Payment</Text>
              <Text style={styles.optionValue}>Cash on Delivery</Text>
            </View>

            <View style={styles.optionRow}>
              <Text style={styles.optionLabel}>Promo Code</Text>
              <TouchableOpacity onPress={() => {
                Alert.alert(
                  'Select Discount',
                  '',
                  [
                    { text: '20%', onPress: () => applyPromoCode('20%') },
                    { text: 'Freeship', onPress: () => applyPromoCode('freeship') },
                    { text: 'Cancel', style: 'cancel' },
                  ]
                );
              }}>
                <Text style={styles.optionValue}>{promoCode ? promoCode : 'Pick discount'}</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.optionRow}>
              <Text style={styles.optionLabel}>Total Cost</Text>
              <Text style={styles.totalCost}>${totalAmount.toFixed(2)}</Text>
            </View>

            <Text style={styles.termsText}>
              By placing an order you agree to our Terms And Conditions
            </Text>

            <TouchableOpacity style={styles.placeOrderButton} onPress={handlePlaceOrder}>
              <Text style={styles.placeOrderButtonText}>Place Order</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
  },
  header: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'center',
  },
  cartItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  itemName: {
    fontSize: 16,
  },
  itemPrice: {
    fontSize: 16,
    color: '#b2275b',
  },
  itemQuantity: {
    fontSize: 16,
  },
  checkoutButton: {
    backgroundColor: '#b2275b',
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 15,
    borderRadius: 10,
    marginTop: 20,
    alignItems: 'center',
  },
  checkoutText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  emptyText: {
    textAlign: 'center',
    fontSize: 16,
    color: '#666',
    marginTop: 20,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalContent: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 20,
    margin: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  closeModal: {
    position: 'absolute',
    top: 10,
    right: 10,
  },
  optionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
  },
  optionLabel: {
    fontSize: 16,
    color: '#666',
  },
  optionValue: {
    fontSize: 16,
    color: '#000',
  },
  totalCost: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#b2275b',
  },
  termsText: {
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
    marginVertical: 10,
  },
  placeOrderButton: {
    backgroundColor: '#b2275b',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
  },
  placeOrderButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});