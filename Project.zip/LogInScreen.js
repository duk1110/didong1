import React, { useState, useContext } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Image, Alert } from 'react-native';
import * as FileSystem from 'expo-file-system';
import AppContext from './AppContext';
import AsyncStorage from '@react-native-async-storage/async-storage';

const LogInScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);
  const { setIsLoggedIn } = useContext(AppContext);

  const filePath = `${FileSystem.documentDirectory}users.json`;

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('Lỗi', 'Vui lòng nhập email và mật khẩu');
      setError('Vui lòng nhập email và mật khẩu');
      return;
    }

    try {
      const fileInfo = await FileSystem.getInfoAsync(filePath);
      if (!fileInfo.exists) {
        Alert.alert('Lỗi', 'Chưa có tài khoản. Vui lòng đăng ký ngay.');
        setError('Chưa có tài khoản. Vui lòng đăng ký ngay.');
        return;
      }

      const fileContent = await FileSystem.readAsStringAsync(filePath);
      const users = JSON.parse(fileContent);

      const user = users.find(
        (user) => user.email === email && user.password === password
      );

      if (user) {
        await AsyncStorage.setItem('currentUserEmail', email);
        setIsLoggedIn(true); // Rely on App.js to switch to MainTabScreen
        Alert.alert('Thành công', 'Đăng nhập thành công!');
      } else {
        Alert.alert('Lỗi', 'Email hoặc mật khẩu không đúng');
        setError('Email hoặc mật khẩu không đúng');
      }
    } catch (error) {
      console.log('Lỗi khi đăng nhập:', error);
      Alert.alert('Lỗi', 'Đã xảy ra lỗi. Vui lòng thử lại.');
      setError('Đã xảy ra lỗi. Vui lòng thử lại.');
    }
  };

  return (
    <View style={styles.container}>
      <Image source={{ uri: 'https://via.placeholder.com/50' }} style={styles.logo} />
      <Text style={styles.title}>Đăng Nhập</Text>
      <Text style={styles.subtitle}>Nhập email và mật khẩu</Text>
      {error && <Text style={styles.errorText}>{error}</Text>}
      <TextInput
        style={styles.input}
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        placeholder="Email"
        autoCapitalize="none"
      />
      <TextInput
        style={styles.input}
        value={password}
        onChangeText={setPassword}
        secureTextEntry
        placeholder="Mật khẩu"
      />
      <TouchableOpacity onPress={() => navigation.navigate('ForgetPassword')}>
        <Text style={styles.forgotText}>Quên mật khẩu?</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.button} onPress={handleLogin}>
        <Text style={styles.buttonText}>Đăng Nhập</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => navigation.navigate('SignUp')}>
        <Text style={styles.signUpText}>Chưa có tài khoản? Đăng ký ngay</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  logo: {
    width: 50,
    height: 50,
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    color: '#000',
    fontWeight: 'bold',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 14,
    color: '#666',
    marginBottom: 20,
  },
  input: {
    width: '100%',
    padding: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    marginBottom: 10,
    backgroundColor: '#fff',
  },
  forgotText: {
    color: '#b2275b',
    fontSize: 14,
    alignSelf: 'flex-end',
    marginBottom: 20,
  },
  button: {
    backgroundColor: '#b2275b',
    padding: 15,
    borderRadius: 10,
    width: '100%',
    alignItems: 'center',
    marginBottom: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
  signUpText: {
    color: '#b2275b',
    fontSize: 14,
  },
  errorText: {
    fontSize: 16,
    color: 'red',
    marginBottom: 10,
  },
});

export default LogInScreen;