import React, { useState, useContext } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Image, Alert } from 'react-native';
import * as FileSystem from 'expo-file-system';
import AppContext from './AppContext'; // Use default import
import AsyncStorage from '@react-native-async-storage/async-storage';
import { KeyboardAvoidingView, Platform, ScrollView } from 'react-native';


const SignUpScreen = ({ navigation }) => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('');
  const [district, setDistrict] = useState('');
  const [street, setStreet] = useState('');
  const [error, setError] = useState(null);
  const { setIsLoggedIn } = useContext(AppContext);

  // Đường dẫn đến tệp JSON
  const filePath = `${FileSystem.documentDirectory}users.json`;

  const handleSignUp = async () => {
    if (!username || !email || !password || !phone || !city || !district || !street) {
      Alert.alert('Lỗi', 'Vui lòng điền đầy đủ các trường');
      setError('Vui lòng điền đầy đủ các trường');
      return;
    }

    try {
      const newUser = {
        username,
        email,
        password,
        phone,
        address: { city, district, street },
      };

      // Đọc danh sách người dùng hiện có từ tệp JSON
      let users = [];
      try {
        const fileInfo = await FileSystem.getInfoAsync(filePath);
        if (fileInfo.exists) {
          const fileContent = await FileSystem.readAsStringAsync(filePath);
          users = JSON.parse(fileContent);
        }
      } catch (error) {
        console.log('Lỗi khi đọc tệp JSON:', error);
      }

      // Kiểm tra xem người dùng đã tồn tại chưa
      const userExists = users.some(
        (user) => user.email === email || user.username === username
      );
      if (userExists) {
        Alert.alert('Lỗi', 'Người dùng với email hoặc tên người dùng này đã tồn tại');
        setError('Người dùng với email hoặc tên người dùng này đã tồn tại');
        return;
      }

      // Thêm người dùng mới vào mảng
      users.push(newUser);

      // Ghi mảng người dùng vào tệp JSON
      await FileSystem.writeAsStringAsync(filePath, JSON.stringify(users, null, 2));

      // Lưu email vào AsyncStorage để sử dụng cho xác thực
      await AsyncStorage.setItem('currentUserEmail', email);

      // Đặt trạng thái đăng nhập về false để yêu cầu đăng nhập
      setIsLoggedIn(false);
      navigation.navigate('LogIn');
      Alert.alert('Thành công', 'Đăng ký thành công! Vui lòng đăng nhập để tiếp tục.');
    } catch (error) {
      console.log('Lỗi khi đăng ký:', error);
      Alert.alert('Lỗi', 'Đã xảy ra lỗi. Vui lòng thử lại.');
      setError('Đã xảy ra lỗi. Vui lòng thử lại.');
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 0 }}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={0} // bạn có thể điều chỉnh offset này nếu cần
    >
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.container}>
          <Image source={{ uri: 'https://via.placeholder.com/50' }} style={styles.logo} />
          <Text style={styles.title}>Đăng Ký</Text>
          <Text style={styles.subtitle}>Nhập thông tin của bạn để tiếp tục</Text>
          {error && <Text style={styles.errorText}>{error}</Text>}
          <TextInput
            style={styles.input}
            value={username}
            onChangeText={setUsername}
            placeholder="Tên người dùng"
          />
          <TextInput
            style={styles.input}
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            placeholder="Email"
            autoCapitalize="none"
          />
          <TextInput
            style={styles.input}
            value={phone}
            onChangeText={setPhone}
            keyboardType="phone-pad"
            placeholder="Số điện thoại"
          />
          <TextInput
            style={styles.input}
            value={city}
            onChangeText={setCity}
            placeholder="Tỉnh/Thành phố"
          />
          <TextInput
            style={styles.input}
            value={district}
            onChangeText={setDistrict}
            placeholder="Quận/Huyện"
          />
          <TextInput
            style={styles.input}
            value={street}
            onChangeText={setStreet}
            placeholder="Số nhà, tên đường"
          />
          <TextInput
            style={styles.input}
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            placeholder="Mật khẩu"
          />
          <Text style={styles.termsText}>
            Bằng cách tiếp tục, bạn đồng ý với Điều khoản Dịch vụ và Chính sách Quyền riêng tư của chúng tôi
          </Text>
          <TouchableOpacity style={styles.button} onPress={handleSignUp}>
            <Text style={styles.buttonText}>Đăng Ký</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.navigate('LogIn')}>
            <Text style={styles.signInText}>Đã có tài khoản? Đăng Nhập</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );  
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  logo: {
    width: 50,
    height: 50,
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    color: '#000',
    fontWeight: 'bold',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 14,
    color: '#666',
    marginBottom: 20,
  },
  input: {
    width: '100%',
    padding: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    marginBottom: 10,
    backgroundColor: '#fff',
  },
  termsText: {
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
    marginBottom: 20,
  },
  button: {
    backgroundColor: '#b2275b',
    padding: 15,
    borderRadius: 10,
    width: '100%',
    alignItems: 'center',
    marginBottom: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
  signInText: {
    color: '#b2275b',
    fontSize: 14,
  },
  errorText: {
    fontSize: 16,
    color: 'red',
    marginBottom: 10,
  },
});

export default SignUpScreen;