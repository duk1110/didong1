import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, Image, TextInput, FlatList, TouchableOpacity, StyleSheet, Dimensions, Modal } from 'react-native';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import * as FileSystem from 'expo-file-system';
import AsyncStorage from '@react-native-async-storage/async-storage';
import productsData from '../assets/data/products.json';
import { imageMap } from './imageMap';

const { width } = Dimensions.get('window');

// Danh sách banner
const banners = [
  { id: 1, image: require('../assets/Omegon_130_650_EQ-320_Slider_EN.jpg') },
  { id: 2, image: require('../assets/Omegon_RC_+_ZWO_AM5_Slider_EN.jpg') },
  { id: 3, image: require('../assets/Omegon_Sternfeldglas_2x54_Slider_EN.jpg') },
];

const HomeScreen = () => {
  const navigation = useNavigation();
  const [userLocation, setUserLocation] = useState('');
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [shuffledProducts, setShuffledProducts] = useState([]);
  const [currentBannerIndex, setCurrentBannerIndex] = useState(0);

  const getCurrentUserEmail = async () => {
    try {
      const email = await AsyncStorage.getItem('currentUserEmail');
      return email || null;
    } catch (error) {
      console.error('Lỗi khi lấy email từ AsyncStorage:', error);
      return null;
    }
  };

  const fetchUserLocation = async () => {
    try {
      const currentUserEmail = await getCurrentUserEmail();
      if (!currentUserEmail) {
        setUserLocation('Người dùng chưa đăng nhập');
        return;
      }

      const filePath = `${FileSystem.documentDirectory}users.json`;
      const fileContent = await FileSystem.readAsStringAsync(filePath);
      const usersData = JSON.parse(fileContent);

      const user = usersData.find(user => user.email === currentUserEmail);
      if (user && user.address) {
        const district = user.address.district || '';
        const city = user.address.city || '';
        setUserLocation(`${district}, ${city}`);
      } else {
        setUserLocation('Không tìm thấy thông tin người dùng');
      }
    } catch (error) {
      console.error('Lỗi khi đọc users.json:', error);
      setUserLocation('Lỗi khi tải địa chỉ');
    }
  };

  const refreshScreen = () => {
    setSearchQuery('');
    setShuffledProducts([...productsData].sort(() => Math.random() - 0.5).slice(0, 6));
    fetchUserLocation();
  };

  useEffect(() => {
    refreshScreen();
  }, []);

  useFocusEffect(
    useCallback(() => {
      refreshScreen();
    }, [])
  );

  const filteredProducts = shuffledProducts.filter(product =>
    product.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAddToCart = async (product) => {
    try {
      const cart = await AsyncStorage.getItem('cart');
      const cartArray = cart ? JSON.parse(cart) : [];
      const existingItem = cartArray.find(item => item.id === product.id);

      if (existingItem) {
        existingItem.quantity += 1;
      } else {
        cartArray.push({ ...product, quantity: 1 });
      }

      await AsyncStorage.setItem('cart', JSON.stringify(cartArray));
      setShowSuccessModal(true);
      setTimeout(() => setShowSuccessModal(false), 1500);
    } catch (error) {
      console.error('Error adding to cart:', error);
    }
  };

  const renderBannerItem = ({ item, index }) => {
    console.log(`Rendering banner item ${index}:`, item);

    if (!item || !item.id || !item.image) {
      console.warn(`Invalid banner item at index ${index}`);
      return (
        <View style={styles.bannerItem}>
          <Text style={styles.bannerErrorText}>Không tải được banner</Text>
        </View>
      );
    }

    return (
      <View style={styles.bannerItem}>
        <Image
          source={item.image}
          style={styles.bannerImage}
          resizeMode="cover"
          onError={(error) => console.error(`Failed to load image for banner ${item.id}:`, error.nativeEvent)}
        />
      </View>
    );
  };

  const handleScroll = (event) => {
    const contentOffsetX = event.nativeEvent.contentOffset.x;
    const index = Math.round(contentOffsetX / (width - 30));
    setCurrentBannerIndex(index);
  };

  const renderPagination = () => {
    return (
      <View style={styles.paginationContainer}>
        {banners.map((_, index) => (
          <View
            key={index}
            style={[
              styles.paginationDot,
              currentBannerIndex === index ? styles.paginationDotActive : styles.paginationDotInactive,
            ]}
          />
        ))}
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.locationContainer}>
          <Text style={styles.locationText}>Vị trí của bạn</Text>
          <Text style={styles.cityText}>
            <Ionicons name="location-outline" size={16} color="#b2275b" /> {userLocation}
          </Text>
        </View>
      </View>

      <View style={styles.searchBar}>
        <Ionicons name="search-outline" size={20} color="gray" />
        <TextInput
          style={styles.searchInput}
          placeholder="Tìm kiếm sản phẩm thiên văn"
          placeholderTextColor="gray"
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>

      <View style={styles.bannerContainer}>
        <FlatList
          data={banners}
          renderItem={renderBannerItem}
          keyExtractor={(item) => item.id.toString()}
          horizontal
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          onScroll={handleScroll}
          scrollEventThrottle={16}
          snapToInterval={width - 30}
          snapToAlignment="center"
          decelerationRate="fast"
        />
        {renderPagination()}
      </View>

      <FlatList
        data={filteredProducts}
        keyExtractor={(item) => item.id.toString()}
        numColumns={2}
        columnWrapperStyle={styles.productRow}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.itemCard}
            onPress={() => navigation.navigate('ProductDetail', { productId: item.id })}
          >
            <Image source={imageMap[item.image] || { uri: item.image }} style={styles.itemImage} />
            <Text style={styles.itemText}>{item.name}</Text>
            <Text style={styles.itemPrice}>${item.price.toFixed(2)}</Text>
            <TouchableOpacity style={styles.addButton} onPress={() => handleAddToCart(item)}>
              <Text style={styles.addButtonText}>+</Text>
            </TouchableOpacity>
          </TouchableOpacity>
        )}
        ListEmptyComponent={<Text style={styles.emptyText}>Không tìm thấy sản phẩm</Text>}
      />

      <Modal visible={showSuccessModal} transparent animationType="fade">
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Ionicons name="checkmark-circle" size={40} color="#b2275b" />
            <Text style={styles.modalText}>Thêm thành công!</Text>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 15,
  },
  header: {
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
    marginTop: 10,
    backgroundColor: '#fff', // Đổi từ '#FFFFE0' (vàng nhạt) sang '#fff' (trắng)
    borderRadius: 25,
    padding: 5, // Giảm padding từ 15 xuống 10
    height: 25, // Giảm chiều cao từ 100 xuống 80
  },
  locationContainer: {
    alignItems: 'center',
  },
  locationText: {
    fontSize: 12,
    color: 'gray',
  },
  cityText: {
    marginTop:5,
    fontSize: 16,
    fontWeight: 'bold',
    color: '#b2275b',
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
    borderRadius: 25,
    padding: 10,
    marginBottom: 15,
  },
  searchInput: {
    flex: 1,
    marginHorizontal: 10,
    fontSize: 16,
  },
  bannerContainer: {
    marginBottom: 15,
  },
  bannerItem: {
    width: width - 30,
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 10,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 2,
  },
  bannerImage: {
    width: width - 50,
    height: 150,
    borderRadius: 10,
  },
  bannerErrorText: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
  },
  paginationContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 10,
  },
  paginationDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginHorizontal: 4,
  },
  paginationDotActive: {
    backgroundColor: '#b2275b',
  },
  paginationDotInactive: {
    backgroundColor: '#ccc',
  },
  productRow: {
    justifyContent: 'space-between',
  },
  itemCard: {
    backgroundColor: '#fff',
    padding: 10,
    borderRadius: 10,
    margin: 5,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 2,
    width: (width - 40) / 2,
  },
  itemImage: {
    width: 100,
    height: 100,
    borderRadius: 10,
  },
  itemText: {
    marginTop: 5,
    fontSize: 14,
    textAlign: 'center',
  },
  itemPrice: {
    marginTop: 5,
    fontSize: 16,
    fontWeight: 'bold',
    color: '#b2275b',
  },
  addButton: {
    backgroundColor: '#b2275b',
    borderRadius: 15,
    padding: 10,
    marginTop: 5,
  },
  addButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  modalContent: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
  },
  modalText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#b2275b',
    marginTop: 10,
  },
  emptyText: {
    textAlign: 'center',
    fontSize: 16,
    color: '#666',
    marginTop: 20,
  },
});

export default HomeScreen;