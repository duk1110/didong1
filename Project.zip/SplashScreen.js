import React, { useEffect } from 'react';
import { View, Text, Image, StyleSheet, ImageBackground } from 'react-native';
import { useNavigation } from '@react-navigation/native';

const SplashScreen = () => {
  const navigation = useNavigation();

  useEffect(() => {
    const timer = setTimeout(() => {
      navigation.replace('LogIn'); // hoặc navigate nếu muốn quay lại được
    }, 2000);

    return () => clearTimeout(timer);
  }, [navigation]);

  return (
      <View style={styles.container}>
        <Image source={require('../assets/0DHu7o-LogoMakr.png')} style={styles.logo} />
      </View>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    backgroundColor:'#fff'
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logo: {
    width: 250,
    height: 59,
    marginBottom: 20,
  },
  text: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
  },
});

export default SplashScreen;
