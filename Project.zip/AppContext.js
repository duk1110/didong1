import React, { createContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system';

const AppContext = createContext();

export const AppProvider = ({ children }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const checkLoginStatus = async () => {
      try {
        const currentUserEmail = await AsyncStorage.getItem('currentUserEmail');
        if (!currentUserEmail) {
          setIsLoggedIn(false);
          return;
        }

        // Validate currentUserEmail against users.json
        const filePath = `${FileSystem.documentDirectory}users.json`;
        const fileInfo = await FileSystem.getInfoAsync(filePath);
        if (!fileInfo.exists) {
          await AsyncStorage.removeItem('currentUserEmail'); // Clear stale email
          setIsLoggedIn(false);
          return;
        }

        const fileContent = await FileSystem.readAsStringAsync(filePath);
        const users = JSON.parse(fileContent);
        const userExists = users.some((user) => user.email === currentUserEmail);

        if (userExists) {
          setIsLoggedIn(true);
        } else {
          await AsyncStorage.removeItem('currentUserEmail'); // Clear stale email
          setIsLoggedIn(false);
        }
      } catch (error) {
        console.log('Error checking login status:', error);
        await AsyncStorage.removeItem('currentUserEmail'); // Clear on error
        setIsLoggedIn(false);
      }
    };

    checkLoginStatus();
  }, []);

  return (
    <AppContext.Provider value={{ isLoggedIn, setIsLoggedIn }}>
      {children}
    </AppContext.Provider>
  );
};

export default AppContext;