import React, { useState, useEffect } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, ScrollView, Modal } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import productsData from '../assets/data/products.json';
import { imageMap } from './imageMap';
import { useNavigation } from '@react-navigation/native';

const ProductDetailScreen = ({ route }) => {
  const { productId } = route.params;
  const navigation = useNavigation();
  const [product, setProduct] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [isFavourite, setIsFavourite] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);

  useEffect(() => {
    const selectedProduct = productsData.find(item => item.id === productId);
    setProduct(selectedProduct);

    const checkFavourite = async () => {
      try {
        const favourites = await AsyncStorage.getItem('favourites');
        const favouritesArray = favourites ? JSON.parse(favourites) : [];
        setIsFavourite(favouritesArray.some(item => item.id === productId));
      } catch (error) {
        console.error('Error checking favourites:', error);
      }
    };
    checkFavourite();
  }, [productId]);

  const handleAddToCart = async () => {
    try {
      const cart = await AsyncStorage.getItem('cart');
      const cartArray = cart ? JSON.parse(cart) : [];
      const existingItem = cartArray.find(item => item.id === product.id);

      if (existingItem) {
        existingItem.quantity += quantity;
      } else {
        cartArray.push({ ...product, quantity });
      }

      await AsyncStorage.setItem('cart', JSON.stringify(cartArray));
      setShowSuccessModal(true);
      setTimeout(() => setShowSuccessModal(false), 1500); // Ẩn modal sau 1.5 giây
    } catch (error) {
      console.error('Error adding to cart:', error);
    }
  };

  const handleToggleFavourite = async () => {
    try {
      const favourites = await AsyncStorage.getItem('favourites');
      let favouritesArray = favourites ? JSON.parse(favourites) : [];

      if (isFavourite) {
        favouritesArray = favouritesArray.filter(item => item.id !== productId);
      } else {
        favouritesArray.push(product);
      }

      await AsyncStorage.setItem('favourites', JSON.stringify(favouritesArray));
      setIsFavourite(!isFavourite);
    } catch (error) {
      console.error('Error toggling favourite:', error);
    }
  };

  if (!product) return <Text>Đang tải...</Text>;

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#000" />
        </TouchableOpacity>
        <TouchableOpacity onPress={handleToggleFavourite}>
          <Ionicons name={isFavourite ? "heart" : "heart-outline"} size={24} color="#b2275b" />
        </TouchableOpacity>
      </View>

      <Image source={imageMap[product.image] || { uri: product.image }} style={styles.productImage} />

      <View style={styles.productDetails}>
        <Text style={styles.productName}>{product.name}</Text>
        <Text style={styles.productPrice}>${product.price.toFixed(2)}</Text>

        <View style={styles.quantityContainer}>
          <TouchableOpacity onPress={() => setQuantity(Math.max(1, quantity - 1))} style={styles.quantityButton}>
            <Text style={styles.quantityText}>-</Text>
          </TouchableOpacity>
          <Text style={styles.quantity}>{quantity}</Text>
          <TouchableOpacity onPress={() => setQuantity(quantity + 1)} style={styles.quantityButton}>
            <Text style={styles.quantityText}>+</Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.sectionTitle}>Chi tiết sản phẩm</Text>
        <Text style={styles.detailText}>{product.description}</Text>

        <Text style={styles.sectionTitle}>Giá</Text>
        <Text style={styles.detailText}>${product.price.toFixed(2)}</Text>
      </View>

      <TouchableOpacity style={styles.addButton} onPress={handleAddToCart}>
        <Text style={styles.addButtonText}>Thêm vào giỏ hàng</Text>
      </TouchableOpacity>

      <Modal visible={showSuccessModal} transparent animationType="fade">
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Ionicons name="checkmark-circle" size={40} color="#b2275b" />
            <Text style={styles.modalText}>Thêm thành công!</Text>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 15,
  },
  productImage: {
    width: '100%',
    height: 200,
    resizeMode: 'contain',
  },
  productDetails: {
    padding: 15,
  },
  productName: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  productPrice: {
    fontSize: 18,
    color: '#b2275b',
    marginVertical: 10,
  },
  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  quantityButton: {
    backgroundColor: '#f0f0f0',
    padding: 10,
    borderRadius: 5,
  },
  quantityText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  quantity: {
    marginHorizontal: 20,
    fontSize: 18,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginVertical: 10,
  },
  detailText: {
    fontSize: 14,
    color: '#666',
  },
  addButton: {
    backgroundColor: '#b2275b',
    borderRadius: 25,
    padding: 15,
    margin: 15,
    alignItems: 'center',
  },
  addButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  modalContent: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
  },
  modalText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#b2275b',
    marginTop: 10,
  },
});

export default ProductDetailScreen;